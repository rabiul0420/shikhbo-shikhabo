<article class="exam-card">
    <div class="exam-card-head">
        <span class="eyebrow"><?php echo e($exam->subject->name); ?></span>
        <h3><?php echo e($exam->title); ?></h3>
    </div>

    <div class="exam-meta">
        <div class="exam-meta-item">
            <span>Chapter</span>
            <strong><?php echo e($exam->chapter->display_name); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span>Questions</span>
            <strong><?php echo e($exam->questions->count()); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span>Starts</span>
            <strong><?php echo e($exam->starts_at ? $exam->starts_at->format('M d, Y') : 'Not scheduled'); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span>Deadline</span>
            <strong><?php echo e($exam->ends_at ? $exam->ends_at->format('M d, Y') : 'Not scheduled'); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span>Duration</span>
            <strong><?php echo e($exam->duration_minutes ? $exam->duration_minutes . ' mins' : '-'); ?></strong>
        </div>
        <?php if($exam->hasPrizes()): ?>
            <div class="exam-meta-item offer-tooltip" tabindex="0">
                <span>Offer</span>
                <strong>Top 3 gifts</strong>
                <div class="offer-tooltip-popover" role="tooltip">
                    <?php if($exam->first_prize): ?>
                        <div class="offer-tooltip-row">
                            <span>1st</span>
                            <strong><?php echo e($exam->first_prize); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php if($exam->second_prize): ?>
                        <div class="offer-tooltip-row">
                            <span>2nd</span>
                            <strong><?php echo e($exam->second_prize); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php if($exam->third_prize): ?>
                        <div class="offer-tooltip-row">
                            <span>3rd</span>
                            <strong><?php echo e($exam->third_prize); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="exam-card-actions">
        <span class="pill status-<?php echo e($status); ?>"><?php echo e(ucfirst($status)); ?></span>
        <?php if($existingAttempt): ?>
            <span class="pill status-expired">Already participated</span>
            <a class="button secondary" href="<?php echo e(route('exam-attempts.result', $existingAttempt)); ?>">View result</a>
        <?php elseif(! auth()->check()): ?>
            <a class="button secondary" href="<?php echo e(route('exams.show', $exam)); ?>">View details</a>
            <a class="button" href="<?php echo e(route('login', ['redirect_to' => route('exams.show', $exam, false)])); ?>">Login to start</a>
        <?php elseif($status === 'running'): ?>
            <a class="button" href="<?php echo e(route('exams.show', $exam)); ?>">Start exam</a>
        <?php elseif($status === 'upcoming'): ?>
            <span class="pill status-upcoming">Not started</span>
            <a class="button secondary" href="<?php echo e(route('exams.show', $exam)); ?>">View details</a>
        <?php else: ?>
            <a class="button" href="<?php echo e(route('exams.show', $exam)); ?>">View questions</a>
        <?php endif; ?>
    </div>
</article>
<?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/exams/partials/card.blade.php ENDPATH**/ ?>