<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.8/css/dataTables.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-layout">
        <?php echo $__env->make('admin.academic.partials.sidebar', ['activeAcademic' => 'chapters'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="admin-content">
            <section class="panel">
                <div class="section-head">
                    <div>
                        <span class="eyebrow">Academic Setup</span>
                        <h2>Oddhay / Chapter</h2>
                    </div>
                    <button class="js-edit-academic" type="button" data-modal-target="add-chapter">Add Chapter</button>
                </div>
            </section>

            <section class="panel">
                <div class="section-head">
                    <div>
                        <span class="eyebrow">List</span>
                        <h2>Oddhay / Chapter List</h2>
                    </div>
                </div>

                <div class="table-wrap">
                    <table id="chapters-table" class="display admin-data-table">
                        <thead>
                            <tr>
                                <th>Class</th>
                                <th>Subject</th>
                                <th>Chapter No</th>
                                <th>Chapter Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($chapter->academicClass->name); ?></td>
                                    <td><?php echo e($chapter->subject->name); ?></td>
                                    <td><?php echo e($chapter->chapter_no ?: '-'); ?></td>
                                    <td><?php echo e($chapter->name); ?></td>
                                    <td>
                                        <div class="table-actions">
                                            <button class="secondary-action small js-edit-academic" type="button" data-modal-target="edit-chapter-<?php echo e($chapter->id); ?>">Edit</button>
                                            <form method="POST" action="<?php echo e(route('admin.chapters.destroy', $chapter)); ?>" onsubmit="return confirm('Delete this oddhay / chapter?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="danger small" type="submit">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <div class="modal-backdrop" id="add-chapter" aria-hidden="true">
                <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="add-chapter-title">
                    <div class="modal-head">
                        <div>
                            <span class="eyebrow">Add Oddhay / Chapter</span>
                            <h3 id="add-chapter-title">New Oddhay / Chapter</h3>
                        </div>
                        <button class="button secondary small js-close-modal" type="button" data-modal-close="add-chapter">Close</button>
                    </div>

                    <form class="grid grid-2" method="POST" action="<?php echo e(route('admin.chapters.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <label>
                            Class
                            <select name="academic_class_id" data-class-subject-filter>
                                <option value="">Select class</option>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($class->id); ?>"><?php echo e($class->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label>
                            Subject
                            <select name="subject_id" data-subject-options>
                                <option value="">Select subject</option>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subject->id); ?>" data-class-ids="<?php echo e($subject->academicClasses->pluck('id')->implode(',')); ?>"><?php echo e($subject->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label>
                            Chapter No
                            <input name="chapter_no" placeholder="Lesson 1">
                        </label>
                        <label>
                            Chapter Name
                            <input name="name" placeholder="Introduction">
                        </label>
                        <div class="modal-actions">
                            <button class="button secondary js-close-modal" type="button" data-modal-close="add-chapter">Cancel</button>
                            <button type="submit">Add chapter</button>
                        </div>
                    </form>
                </div>
            </div>

            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal-backdrop" id="edit-chapter-<?php echo e($chapter->id); ?>" aria-hidden="true">
                    <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="edit-chapter-<?php echo e($chapter->id); ?>-title">
                        <div class="modal-head">
                            <div>
                                <span class="eyebrow">Edit Oddhay / Chapter</span>
                                <h3 id="edit-chapter-<?php echo e($chapter->id); ?>-title"><?php echo e($chapter->display_name); ?></h3>
                            </div>
                            <button class="button secondary small js-close-modal" type="button" data-modal-close="edit-chapter-<?php echo e($chapter->id); ?>">Close</button>
                        </div>

                        <form class="stack" method="POST" action="<?php echo e(route('admin.chapters.update', $chapter)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <label>
                                Class
                                <select name="academic_class_id" data-class-subject-filter>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->id); ?>" <?php if((int) $chapter->academic_class_id === (int) $class->id): echo 'selected'; endif; ?>><?php echo e($class->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label>
                                Subject
                                <select name="subject_id" data-subject-options>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subject->id); ?>" data-class-ids="<?php echo e($subject->academicClasses->pluck('id')->implode(',')); ?>" <?php if((int) $chapter->subject_id === (int) $subject->id): echo 'selected'; endif; ?>><?php echo e($subject->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label>
                                Chapter No
                                <input name="chapter_no" value="<?php echo e($chapter->chapter_no); ?>">
                            </label>
                            <label>
                                Chapter Name
                                <input name="name" value="<?php echo e($chapter->name); ?>">
                            </label>
                            <div class="modal-actions">
                                <button class="button secondary js-close-modal" type="button" data-modal-close="edit-chapter-<?php echo e($chapter->id); ?>">Cancel</button>
                                <button type="submit">Update chapter</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.academic.partials.scripts', ['tableId' => 'chapters-table'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.querySelectorAll('[data-class-subject-filter]').forEach((classSelect) => {
            const form = classSelect.closest('form');
            const subjectSelect = form?.querySelector('[data-subject-options]');

            if (!subjectSelect) {
                return;
            }

            const filterSubjects = () => {
                const selectedClass = classSelect.value;
                let selectedOptionVisible = false;

                subjectSelect.querySelectorAll('option').forEach((option) => {
                    if (!option.value) {
                        option.hidden = false;
                        return;
                    }

                    const optionClasses = (option.dataset.classIds || '').split(',').filter(Boolean);
                    const isVisible = optionClasses.includes(selectedClass);
                    option.hidden = !isVisible;

                    if (option.selected && isVisible) {
                        selectedOptionVisible = true;
                    }
                });

                if (!selectedOptionVisible) {
                    subjectSelect.value = '';
                }
            };

            classSelect.addEventListener('change', filterSubjects);
            filterSubjects();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Oddhay / Chapter'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/admin/academic/chapters.blade.php ENDPATH**/ ?>