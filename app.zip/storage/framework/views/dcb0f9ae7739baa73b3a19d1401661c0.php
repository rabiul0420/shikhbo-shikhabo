<?php
    $limit = $limit ?? null;
    $totalExams = $classExams->count();
    $visibleExams = $limit ? $classExams->take($limit) : $classExams;
    $academicClass = $academicClass ?? $classExams->first()?->academicClass;
    $showViewAll = $limit && $totalExams > $limit && $academicClass;
?>
<section class="class-section" aria-labelledby="<?php echo e($status); ?>-class-<?php echo e(\Illuminate\Support\Str::slug($className)); ?>">
    <div class="class-section-head">
        <div class="class-title">
            <span class="class-mark"><?php echo e(\Illuminate\Support\Str::of($className)->substr(0, 1)->upper()); ?></span>
            <div>
                <h2 id="<?php echo e($status); ?>-class-<?php echo e(\Illuminate\Support\Str::slug($className)); ?>"><?php echo e($className); ?></h2>
                <p class="muted"><?php echo e($classExams->pluck('subject.name')->filter()->unique()->implode(', ')); ?></p>
            </div>
        </div>
        <div class="class-section-actions">
            <span class="pill class-count"><?php echo e(__('site.exam.exam_count', ['count' => $totalExams])); ?></span>
            <?php if($showViewAll): ?>
                <a class="button class-view-all" href="<?php echo e(route('classes.exams', $academicClass->slug)); ?>">
                    <?php echo e(__('site.exam.view_all_class', ['class' => $className])); ?>

                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="exam-card-grid">
        <?php $__currentLoopData = $visibleExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.exam-card', ['exam' => $exam, 'status' => $status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/partials/exam-class-section.blade.php ENDPATH**/ ?>