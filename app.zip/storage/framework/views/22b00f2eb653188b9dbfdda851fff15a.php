<div class="table-actions">
    <a class="button secondary small" href="<?php echo e(route('admin.exams.results', $exam)); ?>">Result</a>
    <button
        class="secondary-action small js-edit-exam"
        type="button"
        data-modal-target="edit-exam"
        data-edit-url="<?php echo e(route('admin.exams.edit-data', $exam)); ?>"
    >Edit</button>
    <form method="POST" action="<?php echo e(route('exams.destroy', $exam)); ?>" onsubmit="return confirm('Delete this exam?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="danger small" type="submit">Delete</button>
    </form>
</div>
<?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/admin/exams/partials/actions.blade.php ENDPATH**/ ?>