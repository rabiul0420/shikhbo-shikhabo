<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.8/css/dataTables.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-layout">
        <?php echo $__env->make('admin.academic.partials.sidebar', ['activeAcademic' => 'classes'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="admin-content">
            <section class="panel">
                <div class="section-head">
                    <div>
                        <span class="eyebrow">Academic Setup</span>
                        <h2>Class</h2>
                    </div>
                    <button class="js-edit-academic" type="button" data-modal-target="add-class">Add Class</button>
                </div>
            </section>

            <section class="panel">
                <div class="section-head">
                    <div>
                        <span class="eyebrow">List</span>
                        <h2>Class List</h2>
                    </div>
                </div>

                <div class="table-wrap">
                    <table id="classes-table" class="display admin-data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($class->name); ?></td>
                                    <td>
                                        <div class="table-actions">
                                            <button class="secondary-action small js-edit-academic" type="button" data-modal-target="edit-class-<?php echo e($class->id); ?>">Edit</button>
                                            <form method="POST" action="<?php echo e(route('admin.classes.destroy', $class)); ?>" onsubmit="return confirm('Delete this class?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="danger small" type="submit">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <div class="modal-backdrop" id="add-class" aria-hidden="true">
                <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="add-class-title">
                    <div class="modal-head">
                        <div>
                            <span class="eyebrow">Add Class</span>
                            <h3 id="add-class-title">New Class</h3>
                        </div>
                        <button class="button secondary small js-close-modal" type="button" data-modal-close="add-class">Close</button>
                    </div>

                    <form class="stack" method="POST" action="<?php echo e(route('admin.classes.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <label>
                            Class name
                            <input name="name" placeholder="Class 9">
                        </label>
                        <div class="modal-actions">
                            <button class="button secondary js-close-modal" type="button" data-modal-close="add-class">Cancel</button>
                            <button type="submit">Add class</button>
                        </div>
                    </form>
                </div>
            </div>

            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal-backdrop" id="edit-class-<?php echo e($class->id); ?>" aria-hidden="true">
                    <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="edit-class-<?php echo e($class->id); ?>-title">
                        <div class="modal-head">
                            <div>
                                <span class="eyebrow">Edit Class</span>
                                <h3 id="edit-class-<?php echo e($class->id); ?>-title"><?php echo e($class->name); ?></h3>
                            </div>
                            <button class="button secondary small js-close-modal" type="button" data-modal-close="edit-class-<?php echo e($class->id); ?>">Close</button>
                        </div>

                        <form class="stack" method="POST" action="<?php echo e(route('admin.classes.update', $class)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <label>
                                Class name
                                <input name="name" value="<?php echo e($class->name); ?>">
                            </label>
                            <div class="modal-actions">
                                <button class="button secondary js-close-modal" type="button" data-modal-close="edit-class-<?php echo e($class->id); ?>">Cancel</button>
                                <button type="submit">Update class</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.academic.partials.scripts', ['tableId' => 'classes-table'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Class'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/admin/academic/classes.blade.php ENDPATH**/ ?>