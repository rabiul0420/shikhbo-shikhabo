<?php
    $existingAttempt = auth()->check() && ! auth()->user()->is_admin
        ? $exam->attempts->first()
        : null;
    $statusLabel = __('site.home.status_' . $status);
?>
<article class="exam-card">
    <div class="exam-card-head">
        <span class="eyebrow"><?php echo e($exam->subject->name); ?></span>
        <h3><?php echo e($exam->title); ?></h3>
    </div>

    <div class="exam-meta">
        <div class="exam-meta-item">
            <span><?php echo e(__('site.exam.chapter')); ?></span>
            <strong><?php echo e($exam->chapter->display_name); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span><?php echo e(__('site.exam.questions')); ?></span>
            <strong><?php echo e($exam->questions->count()); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span><?php echo e(__('site.exam.starts')); ?></span>
            <strong><?php echo e($exam->starts_at ? $exam->starts_at->format('M d, Y') : __('site.exam.not_scheduled')); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span><?php echo e(__('site.exam.deadline')); ?></span>
            <strong><?php echo e($exam->ends_at ? $exam->ends_at->format('M d, Y') : __('site.exam.not_scheduled')); ?></strong>
        </div>
        <div class="exam-meta-item">
            <span><?php echo e(__('site.exam.duration')); ?></span>
            <strong><?php echo e($exam->duration_minutes ? __('site.exam.minutes', ['count' => $exam->duration_minutes]) : '-'); ?></strong>
        </div>
        <?php if($exam->hasPrizes()): ?>
            <div class="exam-meta-item offer-tooltip" tabindex="0">
                <span><?php echo e(__('site.exam.offer')); ?></span>
                <strong><?php echo e(__('site.exam.top_gifts')); ?></strong>
                <div class="offer-tooltip-popover" role="tooltip">
                    <?php if($exam->first_prize): ?>
                        <div class="offer-tooltip-row">
                            <span><?php echo e(app()->getLocale() === 'bn' ? '১ম' : '1st'); ?></span>
                            <strong><?php echo e($exam->first_prize); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php if($exam->second_prize): ?>
                        <div class="offer-tooltip-row">
                            <span><?php echo e(app()->getLocale() === 'bn' ? '২য়' : '2nd'); ?></span>
                            <strong><?php echo e($exam->second_prize); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php if($exam->third_prize): ?>
                        <div class="offer-tooltip-row">
                            <span><?php echo e(app()->getLocale() === 'bn' ? '৩য়' : '3rd'); ?></span>
                            <strong><?php echo e($exam->third_prize); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="exam-card-actions">
        <span class="pill status-<?php echo e($status); ?>"><?php echo e($statusLabel); ?></span>
        <?php if($existingAttempt): ?>
            <span class="pill status-expired"><?php echo e(__('site.exam.already_taken')); ?></span>
            <a class="button secondary" href="<?php echo e(route('exam-attempts.result', $existingAttempt)); ?>"><?php echo e(__('site.exam.view_result')); ?></a>
        <?php elseif(! auth()->check()): ?>
            <a class="button secondary" href="<?php echo e(route('exams.show', $exam->slug)); ?>"><?php echo e(__('site.exam.view_details')); ?></a>
            <a class="button" href="<?php echo e(route('login', ['redirect_to' => route('exams.show', $exam->slug, false)])); ?>"><?php echo e(__('site.exam.login_to_start')); ?></a>
        <?php elseif($status === 'running'): ?>
            <a class="button" href="<?php echo e(route('exams.show', $exam->slug)); ?>"><?php echo e(__('site.exam.start_exam')); ?></a>
        <?php elseif($status === 'upcoming'): ?>
            <span class="pill status-upcoming"><?php echo e(__('site.exam.not_started')); ?></span>
            <a class="button secondary" href="<?php echo e(route('exams.show', $exam->slug)); ?>"><?php echo e(__('site.exam.view_details')); ?></a>
        <?php else: ?>
            <a class="button" href="<?php echo e(route('exams.show', $exam->slug)); ?>"><?php echo e(__('site.exam.view_questions')); ?></a>
        <?php endif; ?>
    </div>
</article>
<?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/partials/exam-card.blade.php ENDPATH**/ ?>