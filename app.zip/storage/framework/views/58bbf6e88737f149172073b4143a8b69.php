<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.8/css/dataTables.dataTables.min.css">
    <style>
        .class-picker {
            display: grid;
            gap: 10px;
            padding: 12px;
            border: 1px solid #d8dee6;
            background: #f8fafc;
        }

        .class-picker legend {
            padding: 0 6px;
            color: #343a40;
            font-size: 13px;
            font-weight: 800;
        }

        .class-picker-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(148px, 1fr));
            gap: 8px;
        }

        .class-choice {
            position: relative;
            display: flex;
            align-items: center;
            gap: 8px;
            min-height: 42px;
            padding: 9px 10px;
            border: 1px solid #d8dee6;
            background: #ffffff;
            color: #1f2d3d;
            font-weight: 700;
            cursor: pointer;
            transition: border-color .14s ease, background .14s ease, box-shadow .14s ease;
        }

        .class-choice:hover {
            border-color: #93c5fd;
            background: #f0f7ff;
        }

        .class-choice input {
            width: 16px;
            height: 16px;
            margin: 0;
            accent-color: #2563eb;
        }

        .class-choice:has(input:checked) {
            border-color: #2563eb;
            background: #eff6ff;
            box-shadow: inset 3px 0 0 #2563eb;
        }

        .class-picker-note {
            color: #6c757d;
            font-size: 12px;
            font-weight: 700;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-layout">
        <?php echo $__env->make('admin.academic.partials.sidebar', ['activeAcademic' => 'subjects'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="admin-content">
            <section class="panel">
                <div class="section-head">
                    <div>
                        <span class="eyebrow">Academic Setup</span>
                        <h2>Subject</h2>
                    </div>
                    <button class="js-edit-academic" type="button" data-modal-target="add-subject">Add Subject</button>
                </div>
            </section>

            <section class="panel">
                <div class="section-head">
                    <div>
                        <span class="eyebrow">List</span>
                        <h2>Subject List</h2>
                    </div>
                </div>

                <div class="table-wrap">
                    <table id="subjects-table" class="display admin-data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Class</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($subject->name); ?></td>
                                    <td><?php echo e($subject->academicClasses->pluck('name')->implode(', ') ?: 'Unassigned'); ?></td>
                                    <td>
                                        <div class="table-actions">
                                            <button class="secondary-action small js-edit-academic" type="button" data-modal-target="edit-subject-<?php echo e($subject->id); ?>">Edit</button>
                                            <form method="POST" action="<?php echo e(route('admin.subjects.destroy', $subject)); ?>" onsubmit="return confirm('Delete this subject?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="danger small" type="submit">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <div class="modal-backdrop" id="add-subject" aria-hidden="true">
                <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="add-subject-title">
                    <div class="modal-head">
                        <div>
                            <span class="eyebrow">Add Subject</span>
                            <h3 id="add-subject-title">New Subject</h3>
                        </div>
                        <button class="button secondary small js-close-modal" type="button" data-modal-close="add-subject">Close</button>
                    </div>

                    <form class="stack" method="POST" action="<?php echo e(route('admin.subjects.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <label>
                            Subject name
                            <input name="name" value="<?php echo e(old('name')); ?>" placeholder="Mathematics">
                        </label>
                        <fieldset class="class-picker" data-class-picker>
                            <legend>Classes</legend>
                            <div class="class-picker-grid">
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="class-choice">
                                        <input
                                            type="checkbox"
                                            name="academic_class_ids[]"
                                            value="<?php echo e($class->id); ?>"
                                            <?php if(in_array((string) $class->id, old('academic_class_ids', []), true)): echo 'checked'; endif; ?>
                                        >
                                        <span><?php echo e($class->name); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <span class="class-picker-note" data-class-picker-note>0 selected</span>
                        </fieldset>
                        <div class="modal-actions">
                            <button class="button secondary js-close-modal" type="button" data-modal-close="add-subject">Cancel</button>
                            <button type="submit">Add subject</button>
                        </div>
                    </form>
                </div>
            </div>

            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal-backdrop" id="edit-subject-<?php echo e($subject->id); ?>" aria-hidden="true">
                    <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="edit-subject-<?php echo e($subject->id); ?>-title">
                        <div class="modal-head">
                            <div>
                                <span class="eyebrow">Edit Subject</span>
                                <h3 id="edit-subject-<?php echo e($subject->id); ?>-title"><?php echo e($subject->name); ?></h3>
                            </div>
                            <button class="button secondary small js-close-modal" type="button" data-modal-close="edit-subject-<?php echo e($subject->id); ?>">Close</button>
                        </div>

                        <form class="stack" method="POST" action="<?php echo e(route('admin.subjects.update', $subject)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <?php
                                $selectedClassIds = old(
                                    'academic_class_ids',
                                    $subject->academicClasses->pluck('id')->map(fn ($id) => (string) $id)->all()
                                );
                            ?>
                            <label>
                                Subject name
                                <input name="name" value="<?php echo e(old('name', $subject->name)); ?>">
                            </label>
                            <fieldset class="class-picker" data-class-picker>
                                <legend>Classes</legend>
                                <div class="class-picker-grid">
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="class-choice">
                                            <input
                                                type="checkbox"
                                                name="academic_class_ids[]"
                                                value="<?php echo e($class->id); ?>"
                                                <?php if(in_array((string) $class->id, $selectedClassIds, true)): echo 'checked'; endif; ?>
                                            >
                                            <span><?php echo e($class->name); ?></span>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <span class="class-picker-note" data-class-picker-note>0 selected</span>
                            </fieldset>
                            <div class="modal-actions">
                                <button class="button secondary js-close-modal" type="button" data-modal-close="edit-subject-<?php echo e($subject->id); ?>">Cancel</button>
                                <button type="submit">Update subject</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.academic.partials.scripts', ['tableId' => 'subjects-table'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.querySelectorAll('[data-class-picker]').forEach((picker) => {
            const note = picker.querySelector('[data-class-picker-note]');
            const checkboxes = Array.from(picker.querySelectorAll('input[type="checkbox"]'));

            const updateNote = () => {
                const selectedCount = checkboxes.filter((checkbox) => checkbox.checked).length;
                note.textContent = `${selectedCount} ${selectedCount === 1 ? 'class' : 'classes'} selected`;
            };

            checkboxes.forEach((checkbox) => checkbox.addEventListener('change', updateNote));
            updateNote();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Subject'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/admin/academic/subjects.blade.php ENDPATH**/ ?>