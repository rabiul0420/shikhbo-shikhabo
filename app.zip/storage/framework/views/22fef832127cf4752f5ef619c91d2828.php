<?php $__env->startSection('content'); ?>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <img class="admin-logo" src="<?php echo e(asset('logo.svg')); ?>" alt="" aria-hidden="true">
                <div>
                    <h2>Shikhbo Shikhabo Admin</h2>
                    <p><?php echo e(auth()->user()->name); ?></p>
                </div>
            </div>

            <nav class="admin-menu" aria-label="Admin navigation">
                <a class="admin-nav-link" href="<?php echo e(route('admin.index')); ?>#dashboard">Dashboard</a>

                <div class="admin-menu-group">
                    <button class="admin-menu-toggle" type="button">
                        Academic Setup
                        <span></span>
                    </button>
                    <div class="admin-submenu">
                        <a class="admin-nav-link" href="<?php echo e(route('admin.academic.classes')); ?>">Class</a>
                        <a class="admin-nav-link" href="<?php echo e(route('admin.academic.subjects')); ?>">Subject</a>
                        <a class="admin-nav-link" href="<?php echo e(route('admin.academic.chapters')); ?>">Oddhay / Chapter</a>
                    </div>
                </div>

                <div class="admin-menu-group is-open">
                    <button class="admin-menu-toggle" type="button">
                        Question
                        <span></span>
                    </button>
                    <div class="admin-submenu">
                        <a class="admin-nav-link" href="<?php echo e(route('admin.index')); ?>#question-list">Question List</a>
                        <a class="admin-nav-link is-active" href="<?php echo e(route('admin.questions.create')); ?>">Question Add</a>
                    </div>
                </div>

                <div class="admin-menu-group">
                    <button class="admin-menu-toggle" type="button">
                        Exam
                        <span></span>
                    </button>
                    <div class="admin-submenu">
                        <a class="admin-nav-link" href="<?php echo e(route('admin.exams.index')); ?>#exam-list">Exam List</a>
                        <a class="admin-nav-link" href="<?php echo e(route('admin.exams.index')); ?>#add-exam">Add Exam</a>
                    </div>
                </div>

                <div class="admin-menu-group">
                    <button class="admin-menu-toggle" type="button">
                        Schools
                        <span></span>
                    </button>
                    <div class="admin-submenu">
                        <a class="admin-nav-link" href="<?php echo e(route('admin.schools.index')); ?>">School List</a>
                        <a class="admin-nav-link" href="<?php echo e(route('admin.schools.index')); ?>#add-school">Add School</a>
                    </div>
                </div>

                <?php if(auth()->user()->is_super_admin): ?>
                    <div class="admin-menu-group">
                        <button class="admin-menu-toggle" type="button">
                            User
                            <span></span>
                        </button>
                        <div class="admin-submenu">
                            <a class="admin-nav-link" href="<?php echo e(route('admin.users.index')); ?>">User List</a>
                            <a class="admin-nav-link" href="<?php echo e(route('admin.users.create')); ?>">Add User</a>
                        </div>
                    </div>
                <?php endif; ?>

                <a class="admin-nav-link admin-menu-direct" href="<?php echo e(route('admin.students.index')); ?>">Student List</a>
                <a class="admin-nav-link admin-menu-direct" href="<?php echo e(route('admin.results.index')); ?>">Result</a>
                <a class="admin-nav-link admin-menu-direct" href="<?php echo e(route('admin.custom-results.index')); ?>">Custom Result</a>
                <a class="admin-nav-link admin-menu-direct" href="<?php echo e(route('admin.gift-recipients.index')); ?>">Gift List</a>

            </nav>
        </aside>

        <div class="admin-content">
            <section class="panel">
                <div class="section-head">
                    <div>
                        <span class="eyebrow">Bulk Question</span>
                        <h2>Many Questions Add</h2>
                    </div>
                </div>

                <form class="stack question-entry-form" method="POST" action="<?php echo e(route('questions.bulk.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <label>
                        Class
                        <select name="academic_class_id">
                            <option value="">Select class</option>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($class->id); ?>" <?php if((string) old('academic_class_id') === (string) $class->id): echo 'selected'; endif; ?>><?php echo e($class->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label>
                        Subject
                        <select name="subject_id">
                            <option value="">Select subject</option>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject->id); ?>" data-class-ids="<?php echo e($subject->academicClasses->pluck('id')->implode(',')); ?>" <?php if((string) old('subject_id') === (string) $subject->id): echo 'selected'; endif; ?>><?php echo e($subject->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label>
                        Oddhay / Chapter
                        <select name="chapter_id" data-selected-chapter="<?php echo e(old('chapter_id')); ?>" disabled>
                            <option value="">Select class and subject first</option>
                        </select>
                    </label>
                    <label>
                        Questions
                        <textarea name="bulk_questions" rows="14" placeholder="1. কোনো বস্তুর অবস্থান পরিবর্তনের হারকে কী বলে?

A) বল
B) বেগ
C) ত্বরণ
D) কাজ

উত্তর: B) বেগ"><?php echo e(old('bulk_questions')); ?></textarea>
                    </label>

                    <button type="submit">Save all questions</button>
                </form>
            </section>

            <?php
                $singleQuestionOpen = old('question_text') || old('options') || old('correct_option') !== null;
            ?>

            <section class="panel single-question-panel <?php echo e($singleQuestionOpen ? 'is-open' : ''); ?>" style="margin-top: 16px;">
                <div class="section-head">
                    <div class="single-question-title">
                        <span class="eyebrow">Question</span>
                        <h2>Question Add</h2>
                    </div>
                    <button
                        class="button secondary js-toggle-single-question"
                        type="button"
                        aria-expanded="<?php echo e($singleQuestionOpen ? 'true' : 'false'); ?>"
                        aria-controls="single-question-form"
                    >
                        <?php echo e($singleQuestionOpen ? 'Close single question' : 'Open single question'); ?>

                    </button>
                </div>

                <form
                    id="single-question-form"
                    class="stack question-entry-form single-question-form"
                    method="POST"
                    action="<?php echo e(route('questions.standalone.store')); ?>"
                    <?php if (! ($singleQuestionOpen)): ?> hidden <?php endif; ?>
                >
                    <?php echo csrf_field(); ?>
                    <label>
                        Class
                        <select name="academic_class_id">
                            <option value="">Select class</option>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($class->id); ?>" <?php if((string) old('academic_class_id') === (string) $class->id): echo 'selected'; endif; ?>><?php echo e($class->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label>
                        Subject
                        <select name="subject_id">
                            <option value="">Select subject</option>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject->id); ?>" data-class-ids="<?php echo e($subject->academicClasses->pluck('id')->implode(',')); ?>" <?php if((string) old('subject_id') === (string) $subject->id): echo 'selected'; endif; ?>><?php echo e($subject->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label>
                        Oddhay / Chapter
                        <select name="chapter_id" data-selected-chapter="<?php echo e(old('chapter_id')); ?>" disabled>
                            <option value="">Select class and subject first</option>
                        </select>
                    </label>
                    <label>
                        Question
                        <textarea name="question_text" placeholder="Write your question here"><?php echo e(old('question_text')); ?></textarea>
                    </label>

                    <div class="option-list">
                        <?php for($i = 0; $i < 4; $i++): ?>
                            <label class="option">
                                <input type="radio" name="correct_option" value="<?php echo e($i); ?>" <?php if(old('correct_option') == $i): echo 'checked'; endif; ?>>
                                <input name="options[]" value="<?php echo e(old('options.' . $i)); ?>" placeholder="Option <?php echo e($i + 1); ?>">
                            </label>
                        <?php endfor; ?>
                    </div>

                    <button type="submit">Save question</button>
                </form>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .single-question-form[hidden] {
            display: none !important;
        }

        .single-question-panel:not(.is-open) .single-question-title {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
        if (window.jQuery) {
            $(function () {
                $('.admin-menu-toggle').on('click', function () {
                    const $group = $(this).closest('.admin-menu-group');
                    const $submenu = $group.children('.admin-submenu');

                    $group.toggleClass('is-open');
                    $submenu.stop(true, true).slideToggle(180);
                });

                const chapterOptionsUrl = <?php echo json_encode(route('admin.academic.chapters.options'), 15, 512) ?>;

                $('.question-entry-form').each(function () {
                    const $form = $(this);
                    const $classSelect = $form.find('select[name="academic_class_id"]');
                    const $subjectSelect = $form.find('select[name="subject_id"]');
                    const $chapterSelect = $form.find('select[name="chapter_id"]');

                    function setChapterPlaceholder(text) {
                        $chapterSelect.empty().append($('<option>', {
                            value: '',
                            text,
                        }));
                    }

                    function filterSubjects() {
                        const selectedClass = String($classSelect.val() || '');
                        let selectedOptionVisible = false;

                        $subjectSelect.find('option').each(function () {
                            const $option = $(this);

                            if (! $option.val()) {
                                $option.prop('hidden', false);
                                return;
                            }

                            const optionClasses = String($option.data('class-ids') || '').split(',').filter(Boolean);
                            const isVisible = optionClasses.includes(selectedClass);
                            $option.prop('hidden', ! isVisible);

                            if ($option.is(':selected') && isVisible) {
                                selectedOptionVisible = true;
                            }
                        });

                        if (! selectedOptionVisible) {
                            $subjectSelect.val('');
                        }
                    }

                    function loadChapterOptions() {
                        const selectedClass = $classSelect.val();
                        const selectedSubject = $subjectSelect.val();

                        if (! selectedClass || ! selectedSubject) {
                            setChapterPlaceholder('Select class and subject first');
                            $chapterSelect.prop('disabled', true);
                            return;
                        }

                        const selectedChapter = String($chapterSelect.data('selected-chapter') || '');

                        setChapterPlaceholder('Loading chapters...');
                        $chapterSelect.prop('disabled', true);

                        $.getJSON(chapterOptionsUrl, {
                            academic_class_id: selectedClass,
                            subject_id: selectedSubject,
                        }).done(function (response) {
                            const chapters = response.chapters || [];

                            setChapterPlaceholder(chapters.length ? 'Select oddhay / chapter' : 'No chapter found');

                            chapters.forEach(function (chapter) {
                                $chapterSelect.append($('<option>', {
                                    value: chapter.id,
                                    text: chapter.name,
                                }));
                            });

                            if (selectedChapter && $chapterSelect.find('option[value="' + selectedChapter + '"]').length) {
                                $chapterSelect.val(selectedChapter);
                            } else {
                                $chapterSelect.data('selected-chapter', '');
                            }

                            $chapterSelect.prop('disabled', chapters.length === 0);
                        }).fail(function () {
                            setChapterPlaceholder('Could not load chapters');
                            $chapterSelect.prop('disabled', true);
                        });
                    }

                    $classSelect.on('change', function () {
                        filterSubjects();
                        $chapterSelect.data('selected-chapter', '');
                        loadChapterOptions();
                    });

                    $subjectSelect.on('change', function () {
                        $chapterSelect.data('selected-chapter', '');
                        loadChapterOptions();
                    });

                    filterSubjects();
                    loadChapterOptions();
                });

                $('.js-toggle-single-question').on('click', function () {
                    const $button = $(this);
                    const $panel = $button.closest('.single-question-panel');
                    const $form = $('#' + $button.attr('aria-controls'));
                    const isOpen = $button.attr('aria-expanded') === 'true';

                    $button.attr('aria-expanded', String(! isOpen));
                    $button.text(isOpen ? 'Open single question' : 'Close single question');
                    $panel.toggleClass('is-open', ! isOpen);

                    if (isOpen) {
                        $form.stop(true, true).slideUp(180, function () {
                            $form.prop('hidden', true).removeAttr('style');
                        });
                    } else {
                        $form.prop('hidden', false).hide().stop(true, true).slideDown(180, function () {
                            $form.removeAttr('style');
                        });
                    }
                });
            });
        }
    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.app', ['title' => 'Question Add'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\shikhbo-shikhabo\resources\views/admin/questions/create.blade.php ENDPATH**/ ?>