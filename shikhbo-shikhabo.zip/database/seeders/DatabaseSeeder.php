<?php

namespace Database\Seeders;

use App\Models\School;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        School::query()
            ->where('title', 'Shikhbo Shikhabo')
            ->whereNull('address')
            ->delete();

        foreach ([
            [
                'title' => 'Shikhbo Shikhabo School',
                'address' => 'Mirpur, Dhaka',
                'status' => 'active',
            ],
            [
                'title' => 'Green Valley School',
                'address' => 'Dhanmondi, Dhaka',
                'status' => 'active',
            ],
            [
                'title' => 'Sunrise Model School',
                'address' => 'Uttara, Dhaka',
                'status' => 'active',
            ],
            [
                'title' => 'Knowledge Academy',
                'address' => 'Chattogram',
                'status' => 'pending',
            ],
            [
                'title' => 'Future Scholars School',
                'address' => 'Sylhet',
                'status' => 'pending',
            ],
        ] as $school) {
            School::updateOrCreate(
                ['title' => $school['title']],
                $school,
            );
        }

        $defaultSchoolId = School::query()
            ->where('title', 'Shikhbo Shikhabo School')
            ->value('id');

        User::updateOrCreate(
            ['email' => 'admin@example.com'],
            [
                'name' => 'Admin User',
                'phone' => '01000000000',
                'school_id' => $defaultSchoolId,
                'password' => 'password',
                'is_admin' => true,
                'is_super_admin' => true,
            ],
        );

        User::updateOrCreate(
            ['email' => 'student@example.com'],
            [
                'name' => 'Student User',
                'phone' => '01900000000',
                'school_id' => $defaultSchoolId,
                'password' => 'password',
                'is_admin' => false,
                'is_super_admin' => false,
            ],
        );
    }
}
